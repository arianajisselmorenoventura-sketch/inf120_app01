public class Natural {
    private int num;

    public Natural() {
        this.num = 0;
    }
    public Natural(int n) {
        this.num = (n >= 0) ? n : 0;
    }
    public void setNum(int n) {
        if (n >= 0) this.num = n;
    }
    public int getNum() {
        return this.num;
    }
    // --- OPERACIONES SOBRE DIGITOS ---
    public int digCant() {
        if (num == 0) return 1;
        int aux = num, cont = 0;
        while (aux > 0) {
            cont++;
            aux /= 10;
        }
        return cont;
    }
    public int obtenerDigito(int pos) {
        int cant = digCant();
        if (pos < 1 || pos > cant) return -1;
        int aux = num;
        for (int i = 1; i <= cant - pos; i++) {
            aux /= 10;
        }
        return aux % 10;
    }
    public void digIns(int pos, int valor) {
        int cant = digCant();
        if (pos < 1 || pos > cant + 1 || valor < 0 || valor > 9) return;
        int pow = (int) Math.pow(10, cant - pos + 1);
        int izq = num / pow;
        int der = num % pow;
        this.num = (izq * 10 + valor) * pow + der;
    }
    public void digElim(int pos) {
        int cant = digCant();
        if (pos < 1 || pos > cant) return;
        int pow = (int) Math.pow(10, cant - pos);
        int izq = num / (pow * 10);
        int der = num% pow;
        this.num = izq * pow + der;
    }
    public int digSuma() {
        int aux = num, suma = 0;
        while (aux > 0) {
            suma += aux % 10;
            aux /= 10;
        }
        return suma;
    }
    public int digPares() {
        int aux = num, res = 0, mult = 1;
        while (aux > 0) {
            int d = aux % 10;
            if (d % 2 == 0) {
                res = d * mult + res;
                mult *= 10;
            }
            aux /= 10;
        }
        return res;
    }
    public int digImpares() {
        int aux = num, res = 0, mult = 1;
        while (aux > 0) {
            int d = aux % 10;
            if (d % 2 != 0) {
                res = d * mult + res;
                mult *= 10;
            }
            aux /= 10;
        }
        return res;
    }
    private boolean esDigitoPrimo(int d) {
        return d == 2 || d == 3 || d == 5 || d == 7;
    }
    public int digPrimos() {
        int aux = num, res = 0, mult = 1;
        while (aux > 0) {
            int d = aux % 10;
            if (esDigitoPrimo(d)) {
                res = d * mult + res;
                mult *= 10;
            }
            aux /= 10;
        }
        return res;
    }
    public int digMayor() {
        if (num == 0) return 0;
        int aux = num, mayor = 0;
        while (aux > 0) {
            int d = aux % 10;
            if (d > mayor) mayor = d;
            aux /= 10;
        }
        return mayor;
    }
    public int digMenor() {
        if (num == 0) return 0;
        int aux = num, menor = 9;
        while (aux > 10) {
            int d = aux % 10;
            if (d < menor) menor = d;
            aux /= 10;
        }
        return menor;
    }
    // --- OPERACIONES SOBRE ENTEROS ---
    public int invertir() {
        int aux = num, inv = 0;
        while (aux > 0) {
            inv = inv * 10 + (aux % 10);
            aux /= 10;
        }
        return inv;
    }
    public boolean esCapicua() { return num == invertir(); }
    public boolean esPar() { return num % 2 == 0; }
    public boolean esImpar() { return num % 2 != 0; }

    public boolean esPrimo() {
        if (num <= 1) return false;
        if (num <= 3) return true;
        if (num % 2 == 0 || num % 3 == 0) return false;
        for (int i = 5; i * i <= num; i += 6) {
            if (num % i == 0 || num % (i + 2) == 0) return false;
        }
        return true;
    }

    // --- CONVERSIONES ---

    public String aBaseN(int base) {
        if (base < 2 || base > 16) return "Base no válida";
        if (num == 0) return "0";
        StringBuilder sb = new StringBuilder();
        int aux = num;
        char[] hexDigits = "0123456789ABCDEF".toCharArray();
        while (aux > 0) {
            sb.insert(0, hexDigits[aux % base]);
            aux /= base;
        }
        return sb.toString();
    }

    public String aBinario() { return aBaseN(2); }
    public String aOctal() { return aBaseN(8); }
    public String aHexadecimal() { return aBaseN(16); }

    public String aRomano() {
        if (num <= 0 || num > 3999) return "Fuera de rango (1-3999)";
        int[] valores = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] letras = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        int aux = num;
        for (int i = 0; i < valores.length; i++) {
            while (aux >= valores[i]) {
                sb.append(letras[i]);
                aux -= valores[i];
            }
        }
        return sb.toString();
    }

    public String aLiteral() {
        if (num == 0) return "Cero";
        return convertirLiteral(num).trim();
    }

    private String convertirLiteral(int n) {
        String[] unidades = {"", "Un ", "Dos ", "Tres ", "Cuatro ", "Cinco ", "Seis ", "Siete ", "Ocho ", "Nueve "};
        String[] decenas = {"", "Diez ", "Veinte ", "Treinta ", "Cuarenta ", "Cincuenta ", "Sesenta ", "Setenta ", "Ochenta ", "Noventa "};
        String[] especiales = {"Diez ", "Once ", "Doce ", "Trece ", "Catorce ", "Quince ", "Dieciséis ", "Diecisiete ", "Dieciocho ", "Diecinueve "};
        String[] centenas = {"", "Ciento ", "DosCientos ", "TresCientos ", "CuatroCientos ", "Quinientos ", "SeisCientos ", "SieteCientos ", "OchoCientos ", "NoveCientos "};

        if (n == 100) return "Cien ";
        if (n < 10) return unidades[n];
        if (n < 20) return especiales[n - 10];
        if (n < 100) {
            int d = n / 10, u = n % 10;
            if (d == 2 && u > 0) return "Veinti" + unidades[u].toLowerCase();
            return decenas[d] + (u > 0 ? "y " + unidades[u] : "");
        }
        if (n < 1000) return centenas[n / 100] + convertirLiteral(n % 100);
        if (n < 1000000) {
            int miles = n / 1000, resto = n % 1000;
            String strMiles = (miles == 1) ? "Mil " : convertirLiteral(miles) + "Mil ";
            return strMiles + convertirLiteral(resto);
        }
        return String.valueOf(n);
    }
}
