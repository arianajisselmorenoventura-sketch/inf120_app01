import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private Natural natural = new Natural(0);
    private JTextField txtNum = new JTextField("");
    private JTextField txtPos = new JTextField("");
    private JTextField txtVal = new JTextField("");
    private JTextField txtResult = new JTextField();

    public MainFrame() {
        setTitle("Programación I - Clase Natural");
        setSize(520, 420);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Entradas de Texto
        JPanel pnlInput = new JPanel(new GridLayout(4, 2, 5, 5));
        pnlInput.setBorder(BorderFactory.createTitledBorder("Datos de Entrada"));
        pnlInput.add(new JLabel(" Valor Numérico (num):"));
        pnlInput.add(txtNum);
        pnlInput.add(new JLabel(" Posición (pos):"));
        pnlInput.add(txtPos);
        pnlInput.add(new JLabel(" Dígito / Base (val):"));
        pnlInput.add(txtVal);
        pnlInput.add(new JLabel(" RESULTADO:"));
        txtResult.setEditable(false);
        txtResult.setFont(new Font("Monospaced", Font.BOLD, 12));
        pnlInput.add(txtResult);
        add(pnlInput, BorderLayout.NORTH);

        // Pestañas
        JTabbedPane tabs = new JTabbedPane();

        // Op. Dígitos
        JPanel pnlDig = new JPanel(new GridLayout(4, 3, 5, 5));
        JButton btnSet = new JButton("Fijar Valor");
        JButton btnCant = new JButton("Cant. Dígitos");
        JButton btnObt = new JButton("Obtener Dígito");
        JButton btnIns = new JButton("Insertar Dígito");
        JButton btnElim = new JButton("Eliminar Dígito");
        JButton btnSuma = new JButton("Suma Dígitos");
        JButton btnPares = new JButton("Dígitos Pares");
        JButton btnImp = new JButton("Dígitos Impares");
        JButton btnPrim = new JButton("Dígitos Primos");
        JButton btnMay = new JButton("Dígito Mayor");
        JButton btnMen = new JButton("Dígito Menor");

        pnlDig.add(btnSet); pnlDig.add(btnCant); pnlDig.add(btnObt);
        pnlDig.add(btnIns); pnlDig.add(btnElim); pnlDig.add(btnSuma);
        pnlDig.add(btnPares); pnlDig.add(btnImp); pnlDig.add(btnPrim);
        pnlDig.add(btnMay); pnlDig.add(btnMen);

        // Op. Enteros
        JPanel pnlEnt = new JPanel(new GridLayout(3, 2, 5, 5));
        JButton btnInv = new JButton("Invertir");
        JButton btnCapi = new JButton("¿Es Capicúa?");
        JButton btnPar = new JButton("¿Es Par?");
        JButton btnImpE = new JButton("¿Es Impar?");
        JButton btnPrimoE = new JButton("¿Es Primo?");

        pnlEnt.add(btnInv); pnlEnt.add(btnCapi);
        pnlEnt.add(btnPar); pnlEnt.add(btnImpE);
        pnlEnt.add(btnPrimoE);

        // Conversiones
        JPanel pnlConv = new JPanel(new GridLayout(3, 2, 5, 5));
        JButton btnBin = new JButton("A Binario");
        JButton btnOct = new JButton("A Octal");
        JButton btnHex = new JButton("A Hexadecimal");
        JButton btnBaseN = new JButton("A Base N");
        JButton btnRom = new JButton("A Romano");
        JButton btnLit = new JButton("A Literal");

        pnlConv.add(btnBin); pnlConv.add(btnOct);
        pnlConv.add(btnHex); pnlConv.add(btnBaseN);
        pnlConv.add(btnRom); pnlConv.add(btnLit);

        tabs.addTab("Op. Dígitos", pnlDig);
        tabs.addTab("Op. Enteros", pnlEnt);
        tabs.addTab("Conversiones", pnlConv);
        add(tabs, BorderLayout.CENTER);

        // Eventos
        btnSet.addActionListener(e -> { natural.setNum(Integer.parseInt(txtNum.getText())); txtResult.setText("Fijado: " + natural.getNum()); });
        btnCant.addActionListener(e -> txtResult.setText("Cantidad: " + natural.digCant()));
        btnObt.addActionListener(e -> txtResult.setText("Dígito: " + natural.obtenerDigito(Integer.parseInt(txtPos.getText()))));
        btnIns.addActionListener(e -> { natural.digIns(Integer.parseInt(txtPos.getText()), Integer.parseInt(txtVal.getText())); txtNum.setText(String.valueOf(natural.getNum())); txtResult.setText("Insertado"); });
        btnElim.addActionListener(e -> { natural.digElim(Integer.parseInt(txtPos.getText())); txtNum.setText(String.valueOf(natural.getNum())); txtResult.setText("Eliminado"); });
        btnSuma.addActionListener(e -> txtResult.setText("Suma: " + natural.digSuma()));
        btnPares.addActionListener(e -> txtResult.setText("Pares: " + natural.digPares()));
        btnImp.addActionListener(e -> txtResult.setText("Impares: " + natural.digImpares()));
        btnPrim.addActionListener(e -> txtResult.setText("Primos: " + natural.digPrimos()));
        btnMay.addActionListener(e -> txtResult.setText("Mayor: " + natural.digMayor()));
        btnMen.addActionListener(e -> txtResult.setText("Menor: " + natural.digMenor()));

        btnInv.addActionListener(e -> txtResult.setText("Invertido: " + natural.invertir()));
        btnCapi.addActionListener(e -> txtResult.setText("Capicúa: " + (natural.esCapicua() ? "SÍ" : "NO")));
        btnPar.addActionListener(e -> txtResult.setText("Par: " + (natural.esPar() ? "SÍ" : "NO")));
        btnImpE.addActionListener(e -> txtResult.setText("Impar: " + (natural.esImpar() ? "SÍ" : "NO")));
        btnPrimoE.addActionListener(e -> txtResult.setText("Primo: " + (natural.esPrimo() ? "SÍ" : "NO")));

        btnBin.addActionListener(e -> txtResult.setText("Binario: " + natural.aBinario()));
        btnOct.addActionListener(e -> txtResult.setText("Octal: " + natural.aOctal()));
        btnHex.addActionListener(e -> txtResult.setText("Hex: " + natural.aHexadecimal()));
        btnBaseN.addActionListener(e -> txtResult.setText("Base " + txtVal.getText() + ": " + natural.aBaseN(Integer.parseInt(txtVal.getText()))));
        btnRom.addActionListener(e -> txtResult.setText("Romano: " + natural.aRomano()));
        btnLit.addActionListener(e -> txtResult.setText("Literal: " + natural.aLiteral()));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
